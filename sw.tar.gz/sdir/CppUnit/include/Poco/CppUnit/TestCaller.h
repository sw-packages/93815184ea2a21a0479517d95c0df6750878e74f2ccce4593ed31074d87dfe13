//
// TestCaller.h
//


#ifndef Poco_CppUnit_TestCaller_INCLUDED
#define Poco_CppUnit_TestCaller_INCLUDED

#include "CppUnit/TestCaller.h"

#endif // Poco_CppUnit_TestCaller_INCLUDED
