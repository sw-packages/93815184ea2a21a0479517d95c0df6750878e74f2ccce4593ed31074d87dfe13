//
// TestSetup.h
//


#ifndef Poco_CppUnit_TestSetup_INCLUDED
#define Poco_CppUnit_TestSetup_INCLUDED

#include "CppUnit/TestSetup.h"

#endif // Poco_CppUnit_TestSetup_INCLUDED
