//
// CppUnit.h
//


#ifndef Poco_CppUnit_CppUnit_INCLUDED
#define Poco_CppUnit_CppUnit_INCLUDED

#include "CppUnit/CppUnit.h"

#endif // Poco_CppUnit_CppUnit_INCLUDED
