//
// TestDecorator.h
//


#ifndef Poco_CppUnit_TestDecorator_INCLUDED
#define Poco_CppUnit_TestDecorator_INCLUDED

#include "CppUnit/TestDecorator.h"

#endif // Poco_CppUnit_TestDecorator_INCLUDED
